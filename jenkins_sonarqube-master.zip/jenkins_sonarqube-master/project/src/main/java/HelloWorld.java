/**
 * Project Name    : sonarqube-example
 * Developer       : Osanda Deshan
 * Version         : 1.0.0
 * Date            : 8/8/2019
 * Time            : 4:28 PM
 * Description     :
 **/


public class HelloWorld {

    public void sayHello() {
        System.out.println("Hello World!");
    }

    public void notCovered() {
        System.out.println("This method is not covered by unit tests");
    }


}
