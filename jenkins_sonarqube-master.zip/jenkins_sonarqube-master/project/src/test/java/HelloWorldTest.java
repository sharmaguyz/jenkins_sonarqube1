import org.junit.Test;

/**
 * Project Name    : sonarqube-example
 * Developer       : Osanda Deshan
 * Version         : 1.0.0
 * Date            : 8/9/2019
 * Time            : 8:59 AM
 * Description     :
 **/


public class HelloWorldTest {

    @Test
    public void sayHello() {
        new HelloWorld().sayHello();
    }


}
